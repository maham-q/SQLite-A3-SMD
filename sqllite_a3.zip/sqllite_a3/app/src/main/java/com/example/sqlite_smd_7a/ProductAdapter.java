package com.example.sqlite_smd_7a;

import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

public class ProductAdapter extends ArrayAdapter<Product> {
    Context context;
    int resource;

    public ProductAdapter(@NonNull Context context, int resource, @NonNull ArrayList<Product> objects) {
        super(context, resource, objects);
        this.context = context;
        this.resource = resource;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View v = convertView;
        if (v == null) {
            v = LayoutInflater.from(context).inflate(resource, parent, false);
        }

        TextView tvTitle = v.findViewById(R.id.tvProductTitle);
        ImageView ivEdit = v.findViewById(R.id.ivEdit);
        ImageView ivDelete = v.findViewById(R.id.ivDelete);

        Product p = getItem(position);
        tvTitle.setText(p.getPrice() + " : " + p.getTitle());

        ivEdit.setOnClickListener(view -> showEditDialog(p));
        ivDelete.setOnClickListener(view -> {
            ProductDB db = new ProductDB(context);
            db.open();
            db.remove(p.getId());
            db.close();
            remove(p);
            notifyDataSetChanged();
        });

        return v;
    }

    private void showEditDialog(Product product) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Edit Product");

        View dialogView = LayoutInflater.from(context).inflate(R.layout.activity_main, null);
        builder.setView(dialogView);

        TextView tvProductCrud = dialogView.findViewById(R.id.tvtitle);
        tvProductCrud.setVisibility(View.GONE);


        EditText etTitle = dialogView.findViewById(R.id.etTitle);
        EditText etDate = dialogView.findViewById(R.id.etDate);
        EditText etPrice = dialogView.findViewById(R.id.etPrice);

        dialogView.findViewById(R.id.btnAdd).setVisibility(View.GONE);
        dialogView.findViewById(R.id.btnView).setVisibility(View.GONE);

        etTitle.setText(product.getTitle());
        etDate.setText(product.getDate());
        etPrice.setText(String.valueOf(product.getPrice()));

        builder.setPositiveButton("Update", (dialog, which) -> {
            String newTitle = etTitle.getText().toString();
            String newDate = etDate.getText().toString();
            int newPrice;

            try {
                newPrice = Integer.parseInt(etPrice.getText().toString());
            } catch (NumberFormatException e) {
                newPrice = 0;
            }

            ProductDB db = new ProductDB(context);
            db.open();
            db.updateProduct(product.getId(), newTitle, newDate, newPrice);
            db.close();

            product.setTitle(newTitle);
            product.setDate(newDate);
            product.setPrice(newPrice);
            notifyDataSetChanged();
        });

        builder.setNegativeButton("Cancel", null);
        builder.create().show();
    }
}
