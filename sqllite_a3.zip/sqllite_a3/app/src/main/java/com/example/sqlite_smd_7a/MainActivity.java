package com.example.sqlite_smd_7a;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText etTitle, etDate, etPrice;
    Button btnAdd, btnView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        etTitle = findViewById(R.id.etTitle);
        etDate = findViewById(R.id.etDate);
        etPrice = findViewById(R.id.etPrice);
        btnAdd = findViewById(R.id.btnAdd);
        btnView = findViewById(R.id.btnView);

        btnView.setOnClickListener(view -> startActivity(new Intent(MainActivity.this, ViewProducts.class)));

        btnAdd.setOnClickListener(view -> {
            String title = etTitle.getText().toString();
            String date = etDate.getText().toString();
            int price;

            try {
                price = Integer.parseInt(etPrice.getText().toString());
            } catch (NumberFormatException e) {
                Toast.makeText(MainActivity.this, "Invalid price", Toast.LENGTH_SHORT).show();
                return;
            }

            ProductDB my_db = new ProductDB(MainActivity.this);
            my_db.open();
            my_db.insert(title, date, price);
            my_db.close();

            Toast.makeText(MainActivity.this, "Product Added", Toast.LENGTH_SHORT).show();
            etTitle.setText("");
            etDate.setText("");
            etPrice.setText("");
        });
    }
}
